<?php
session_start();

$is_invalid = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $mypassword = $_POST['password'];

    // Establish database connection (connect.php)
    $connection = require 'connect.php';

    $sql = sprintf("SELECT * FROM staff WHERE email= '%s'", $connection->real_escape_string($email));
    $result = $connection->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verify password without hashing
        if ($row && $row['password'] === $mypassword) {
            $_SESSION["staffID"] = $row["staffID"];
            $_SESSION["roleID"] = $row["roleID"];

            // Redirect based on roleID (both cases redirect to the same page here)
            header("Location: /My%20Project/index2.php");
            exit;
        } else {
            $is_invalid = true;
        }
    } else {
        $is_invalid = true;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container vh-100">
        <div class="row justify-content-center h-100">
            <div class="card w-25 my-auto shadow">
                <div class="card-header text-center">
                    <h2>Login</h2>
                </div>
                <?php if ($is_invalid) : ?>
                <em>Invalid Login</em>
                <?php endif; ?>
                <div class="card-body">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" class="form-control" name="email" required
                                value="<?= htmlspecialchars($_POST["email"] ?? "") ?>" />
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" class="form-control" name="password" required/>
                        </div>
                        <div class="mt-3">
                            <input type="submit" class="btn btn-primary mr-2 w-100" value="Login" name="">
                        </div>
                    </form>
                </div>
                <div class="card-footer text-center">
                    <small>&copy; Anthnoey's Fastfood</small>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
