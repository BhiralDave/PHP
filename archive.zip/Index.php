<?php
session_start();
if (!isset($_SESSION['staffID'])) {
    header("Location: login.php");
    exit;
}
include 'index2.php'; 
$roleID = $_SESSION['roleID'];
$staffID = $_SESSION['staffID'];
 
$connection = require 'connect.php';
 

    // Role 1 and 2 can only see their own details
    $sql = "SELECT * FROM staff WHERE staffID = ?";

 
$stmt = $connection->prepare($sql);
 
$stmt->bind_param("i", $staffID);

 
$stmt->execute();
$result = $stmt->get_result();
 
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fast Food</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container my-5">
<h2>My Details</h2>

<br>
<table class="table">
<thead>
<tr>
<th>Staff ID</th>
<th>Name</th>
<th>Address</th>
<th>Date of Birth</th>
<th>Email</th>
<th>Mobile</th>
</tr>
</thead>
<tbody>
<?php


            while ($row = $result->fetch_assoc()) {
                echo "

<tr>
<td>{$row['staffID']}</td>
<td>{$row['name']}</td>
<td>{$row['address']}</td>
<td>{$row['Dateofbirth']}</td>
<td>{$row['email']}</td>
<td>{$row['mob']}</td>
<td>
<a class='btn btn-primary btn-sm' href='edit2.php?staffID={$row['staffID']}'>Edit</a>

<a class='btn btn-primary btn-sm' href='availability.php?staffID={$row['staffID']}'>Availability</a>
</td>
</tr>
                ";
            }
            ?>
</tbody>
</table>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
