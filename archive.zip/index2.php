<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['roleID'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit;
}

// Check if user has admin permissions (RoleID 3 or 4)
$isAdmin = ($_SESSION['roleID'] == 3 || $_SESSION['roleID'] == 4);

require 'connect.php'; // Include database connection

// Fetch the staff member's name based on their session email
// Assuming the email is stored in the session
if (isset($_SESSION['email'])) {
    $stmt = $connection->prepare("SELECT Name FROM staff WHERE email = ?");
    $stmt->bind_param("s", $_SESSION['email']);
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $staffName = $row['Name'];
        }
    }
}

// Get the current date and time
$currentDateTime = date("l, F j, Y h:i A");

?>
<!-- Your HTML code follows -->
 
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv= "X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title>Index2</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
 
  </head>
  <body>
   
  
 
    <nav class="navbar fixed-top navbar-expand-sm navbar-dark" style="background-color:#35BD17">
    <div class="container">
<a
    href="#"
    class="navbar-brand mb-0 h1">
   
    Anthony's Fast Food
</a>
 
<button
type="button"
data-bs-toggle="collapse"
data-bs-target= "#navbarNav"
class="navbar-toggler"
aria-controls="navbarNav"
aria-expanded="false"
aria-label="Toggle navigation">
 
 
<span class="navbar-toggler-icon"></span>
</button>
 
<div class="collapse navbar-collapse" id="navbarNav">
<ul class="navbar-nav">
    <li class="nav-item active">
    <a href="/My Project/index2.php" class="nav-link active">
Home
</a>
</li>
<?php if ($isAdmin) : ?>
    <li class="nav-item dropdown">
    <a href="#" class="nav-link dropdown-toggle"
    id="navbarDropdown"
    role="button"
    data-bs-toggle="dropdown"
    aria-expanded="false">
 
Manage Staff
 
</a>
<ul class="dropdown-menu"
aria-labelledby="navbarDropdown">
<li><a href="/My Project/create.php"
class="dropdown-item">create</a></li>
<li><a href="/My Project/index3.php"
class="dropdown-item">Update</a></li>
<li><a href="/My Project/index3.php"
class="dropdown-item">Delete</a></li>

 
</ul>
</li>
<?php endif; ?>
 
    
 
    <li class="nav-item active">
    <a href="/My Project/edit2.php" class="nav-link active">
 
My Details

</a>
</li>
<li class="nav-item active">
    <a href="/My Project/Logout.php" class="nav-link active">
 
Log Out
</a>
</li>
 
</ul>
 
</div>
</div>
 
</nav>

</div>
</div>
 
</body>
</html>
 
  </body>
</html>
