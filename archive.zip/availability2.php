<?php
session_start();
if (!isset($_SESSION['roleID'])) {
    header("Location: login.php");
    exit;
}
 
include 'index2.php';
 
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$database = "database_bhiraldave";
 
// Create connection
$connection = new mysqli($servername, $username, $password, $database);
 
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
 
$staffID = "";
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // GET method: show the data of the client
    if (!isset($_GET["staffID"])) {
        header("location: index3.php");
        exit;
    }
 
    $staffID = $_GET["staffID"];
 
    // read the row of the selected client from database table
    $sql = "SELECT * FROM staff WHERE staffID = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("i", $staffID);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
 
    if (!$row) {
        header("location: index3.php");
        exit;
    }
 
    $staffID = $row["staffID"];
}
 
// Fetch the existing availability for the staff
$availability_sql = "SELECT rosterID FROM availability WHERE staffID = ?";
$stmt = $connection->prepare($availability_sql);
$stmt->bind_param("i", $staffID);
$stmt->execute();
$availability_result = $stmt->get_result();
$available_shifts = [];
if ($availability_result->num_rows > 0) {
    while ($row = $availability_result->fetch_assoc()) {
        $available_shifts[] = $row['rosterID'];
    }
}
 
$sql = "SELECT staff.staffID, staff.name, staff.roleID, roster.rosterID, Roster.dateTimeFrom, Roster.dateTimeTo
        FROM staff
        JOIN Role ON staff.roleID = role.roleID
        JOIN rosterRole ON role.roleID = rosterRole.roleID
        JOIN roster ON rosterrole.rosterID = roster.rosterID
        WHERE staff.staffID = ?
        ORDER BY roster.dateTimeFrom";
 
$stmt = $connection->prepare($sql);
$stmt->bind_param("i", $staffID);
$stmt->execute();
$result = $stmt->get_result();
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Availability</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card mt-5">
                    <div class="card-header">
                        <h4>Specify when you are available to work</h4>
                    </div>
                </div>
            </div>
 
            <div class="col-md-12">
                <div class="card-body">
                    <form action="/My Project/availupdate.php" method="POST">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <button type="submit" name="AvailableUpdate-btn" class="btn btn-primary">Update</button>
                                    </th>
                                    <th>staffID</th>
                                    <th>Name</th>
                                    <th>roleID</th>
                                    <th>rosterID</th>
                                    <th>Start</th>
                                    <th>End</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $checked = in_array($row['rosterID'], $available_shifts) ? 'checked' : '';
                                ?>
                                    <tr>
                                        <td style="width:10px; text-align: center;">
                                            <input type="checkbox" name="availableUpdate[]" value="<?= $row['rosterID']; ?>" <?= $checked; ?>>
                                        </td>
                                        <td><?= $row['staffID']; ?></td>
                                        <td><?= $row['name']; ?></td>
                                        <td><?= $row['roleID']; ?></td>
                                        <td><?= $row['rosterID']; ?></td>
                                        <td><?= $row['dateTimeFrom']; ?></td>
                                        <td><?= $row['dateTimeTo']; ?></td>
                                    </tr>
                                <?php
                                    }
                                ?>
                                    <!-- ensure that staffID is also passed to availUpdate.php via hidden input type -->
                                    <input type="hidden" name="staffID" value="<?php echo $staffID; ?>">
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
 
<?php
$stmt->close();
$connection->close();
?>