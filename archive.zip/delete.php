<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['roleID'])) {
    header("Location: login.php");
    exit();
}

// Check if user has admin permissions (RoleID 3 or 4)
$isAdmin = ($_SESSION['roleID'] == 3 || $_SESSION['roleID'] == 4);

if (!$isAdmin) {
    // Redirect non-admin users to a different page or show an error message
    header("Location: index2.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "database_bhiraldave";

// Create connection
$connection = new mysqli($servername, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if staffID is provided in the URL
if (!isset($_GET["staffID"])) {
    header("Location: index3.php");
    exit();
}

$staffID = $_GET["staffID"];

// SQL to delete a record
$sql = "DELETE FROM staff WHERE staffID=$staffID";

if ($connection->query($sql) === TRUE) {
    // Redirect to index3.php after successful deletion
    header("Location: index3.php");
    exit();
} else {
    echo "Error deleting record: " . $connection->error;
}

$connection->close();
?>
