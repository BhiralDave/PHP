<?php
// Start the session
session_start();

include 'index2.php';

$servername = "localhost";
$username = "root";
$password = "";
$database = "database_bhiraldave";

// create connection
$connection = new mysqli($servername, $username, $password, $database);

// check connection
if ($connection->connect_error) {
die("Connection failed: ") .$connection->connect_error;

}

$staffID = "";
$Name = "";
$Dateofbirth = "";
$email = "";
$Mob = "";
$Address = "";
$roleID = "";

$errorMessage = "";
$successMessage = "";

if ($_SERVER[ 'REQUEST_METHOD'] == 'GET') {
// GET method: show the data of the client

if ( !isset($_GET["staffID"]) ) {
header("location: index3.php") ;
exit;

}

$staffID = $_GET["staffID"];

// read the row of the selected client from database table
$sql = "SELECT * FROM staff where staffID=$staffID";
$result= $connection->query($sql);
$row = $result->fetch_assoc();

if (!$row) {
header("location: index3.php") ;
exit;

}
$staffID = $row["staffID"];
$Name = $row["name"];
$Dateofbirth = $row["Dateofbirth"];
$email = $row["email"];
$Mob = $row["mob"];
$Address = $row["address"];
$roleID = $row["roleID"];

}
else {
// POST method: Update the data of the client

    $staffID = $_POST["staffID"];
    $Name = $_POST["Name"];
    $Dateofbirth = $_POST["Dateofbirth"];
    $email = $_POST["email"];
    $Mob = $_POST["Mob"];
    $Address = $_POST["Address"];
    $roleID = $_POST["roleID"];

do {
if (  empty($staffID) || empty($Name) || empty($Dateofbirth) || empty($email) || empty($Mob) || empty($Address) || empty($roleID) ) {
$errorMessage = "All the fields are required";
break;

}

// insert new client into database
$sql = "UPDATE staff " .
        "SET staffID = '$staffID', name='$Name', dateOfBirth='$Dateofbirth', address='$Address', email='$email', Mob='$Mob', roleID='$roleID' ".
        "WHERE staffID = $staffID";

$result = $connection->query($sql);

// check query execution success

if (!$result) {
    $errorMessage = "Invalid query: " . $connection->error;
    break;
}
$successMessage = "Client updated successfully";
header("location: index3.php");
exit;
}

while (false);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anthoney's Fastfood</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <script src=https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js></script>
</head>
<body>
    <div class="container my-5">
        <h2>Staff Details</h2>

        <?php
        if ( !empty($errorMessage) ) {
            echo "
            <div class='alert alert-warning alert-dismissible fade show' role='alert'>
                <strong>$errorMessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'> </button>
            </div>
            ";
        
        }
        ?>
         <form method="post">
        <div class="row mb-3">
            <label class="col-sm-3 col-form-label">StaffID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="staffID" value="<?php echo $staffID; ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-3 col-form-label">Name</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="Name" value="<?php echo $Name; ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-3 col-form-label">Dateofbirth</label>
            <div class="col-sm-6">
                <input type="date" class="form-control" name="Dateofbirth" value="<?php echo $Dateofbirth; ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-3 col-form-label">Email</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="email" value="<?php echo $email; ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-3 col-form-label">Mob</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="Mob" value="<?php echo $Mob; ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-3 col-form-label">Address</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="Address" value="<?php echo $Address; ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-3 col-form-label">RoleID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="roleID" value="<?php echo $roleID; ?>">
            </div>
        </div>

        <?php
        if ( !empty($successMessage) ) {
            echo "
            <div class='row mb-3'>
                <div class='offset-sm-3 col-sm-6'>
                    <div class='alert alert-success alert-dismissible fade show' role='alert'>
                        <strong>$successMessage</strong>
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'> </button>
                    </div>
                </div>
            </div>
            ";
        }
        ?>

        <div class="row mb-3">
            <div class="offset-sm-3 col-sm-3 d-grid">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            <div class="col-sm-3 d-grid">
                <a class="btn btn-outline-primary" href="/khashayarfastfood/Index3.php" role="button">Cancel</a>
            </div>
        </div>
        </form>
    </div>
    
</body>
</html>