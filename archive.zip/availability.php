<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Availability</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
rel="stylesheet">
<script src="
https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container my -5">
<div class="row justify-content-center">
<div class= "col-md-12">
<div class="card mt-5">
<div class="card-header">
<h4>Specify when you are available to work</h4>
</div>
</div>
</div>
<div class = "col-md-12">
<div class="card-body">
<form action="availupdate.php" method="POST">
<table class="table table-bordered table-striped">
<tbody>
<tr>
<th>
<button type="submit" name="AvailableUpdate-btn"
class="btn btn-primary">Update </button>
</th>
<th>StaffID</th>
<th>Name</th>
<th>RoleID</th>
<th>RosterID</th>
<th>Start</th>
<th>End</th>
</tr>
</tbody>
<tbody>
<?php
$servername = "localhost";
$username = "root";
$password = "";
//$database = "My Project";

// create connection

$connection = new mysqli('localhost', 'root', '', 'database_bhiraldave');

// check connection

if ($connection->connect_error) {
die("Connection failed: ").$connection->connect_error;
}
if ($_SERVER['REQUEST_METHOD'] == 'GET') {

// GET method: show the data of the client

if ( !isset($_GET["staffID"]) ) {
header("location: /My Project/index.php");
exit;
}
$staffID = $_GET["staffID"];

// read the row of the selected client from database table
//$sql = "SELECT * FROM staff where staffID=$staffID";
$sql = "SELECT Staff.staffID, Staff.name,
staff.roleID, roster.rosterID, Roster.dateTimeFrom, " .
"Roster.dateTimeTo FROM Staff JOIN Role ON
staff.roleID = role.roleID " .
"JOIN rosterRole ON role.roleID = rosterRole.roleID
" .
"Join roster On rosterrole.rosterID =
roster.rosterid " .
"where staff.staffID=$staffID " .
"ORDER BY roster.dateTimefrom ";
$result= $connection->query($sql);
// don't seem to work
if (empty($result)) {
echo( "nothing");
header("location: /My Project/index.php");
exit;
}
foreach($result as $row) {
?>
<tr>
<td style="width:10px; text-align; center;">
<input type="checkbox" name="
availableUpdate[]" value="<?= $row['rosterID']; ?>">
</td>
<td><?= $row['staffID']; ?></td>
<td><?= $row['name']; ?></td>
<td><?= $row['roleID']; ?></td>
<td><?= $row['rosterID']; ?></td>
<td><?= $row['dateTimeFrom']; ?></td>
<td><?= $row['dateTimeTo']; ?></td>
</tr>
<?php
?>
<!-- ensure that staffID is also passed to
availupdate.php via hidden input type -->
<input type="hidden" name="staffID" value="<?php
echo $staffID; ?>">
<?php
}
}
?>
</tbody>
</table>
</form>
</div>
</div>
</div>
</div>
</body>
</html>

