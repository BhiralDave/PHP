<?php
session_start();
include 'index2.php';  // Adjust the path if necessary

$servername = "localhost";
$username = "root";
$password = "";
$database = "database_bhiraldave";

// Create connection
$connection = new mysqli($servername, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (empty($_POST['staffID'])) {
        echo "Staff ID is missing.";
        exit;
    }
    $staffID = $_POST['staffID'];

    // Get the selected availability shifts from the form
    if (isset($_POST['availableUpdate'])) {
        $selected_shifts = $_POST['availableUpdate'];

        // Delete existing availability for the staff using a prepared statement
        $stmt = $connection->prepare("DELETE FROM availability WHERE staffID = ?");
        $stmt->bind_param("i", $staffID);
        if (!$stmt->execute()) {
            echo "Error deleting old records: " . $stmt->error;
            exit;
        }

        // Insert new availability shifts
        foreach ($selected_shifts as $shift_id) {
            $stmt = $connection->prepare("INSERT INTO availability (staffID, rosterID) VALUES (?, ?)");
            $stmt->bind_param("ii", $staffID, $shift_id);
            if (!$stmt->execute()) {
                echo "Error inserting new records: " . $stmt->error;
                exit;
            }
        }
    }

    // Redirect based on user role
    if ($_SESSION['roleID'] == 3 || $_SESSION['roleID'] == 4) {
        header("Location: /My Project/availability2.php");
        exit;
    }

    if ($_SESSION['roleID'] == 1 || $_SESSION['roleID'] == 2) {
        header("Location: /My Project/availability.php");
        exit;
    }
}
?>
